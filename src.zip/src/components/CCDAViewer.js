import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Button,
} from "@mui/material";
import down from "../images/down.png";
import "./CCDAViewer.css";

const CCDACard = ({ title, dataList }) => {
  const [open, setOpen] = useState(false);

  const toggleTable = () => {
    setOpen(!open);
  };

  // Helper function to render table rows based on data structure
  const renderTableRows = (dataList) => {
    return dataList.map((data, i) => {
      const keys = Object.keys(data);
      return (
        <TableRow key={i} className="tablerow">
          {keys.map((key) => (
            <TableCell key={key}>{data[key]}</TableCell>
          ))}
        </TableRow>
      );
    });
  };

  return (
    <div className="ccda-card">
      <Typography
        variant="h6"
        style={{ display: "flex", alignItems: "center" }}
        onClick={toggleTable}
      >
        <img
          src={down}
          alt="Expand"
          style={{
            marginRight: "10px",
            transform: open ? "rotate(-90deg)" : "none",
            width: "12px",
            height: "12px",
          }}
        />
        {title}
      </Typography>
      {open && (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                {/* Render table headers based on the first item in dataList */}
                {dataList.length > 0 &&
                  Object.keys(dataList[0]).map((key) => (
                    <TableCell key={key}>{key}</TableCell>
                  ))}
              </TableRow>
            </TableHead>
            <TableBody>{renderTableRows(dataList)}</TableBody>
          </Table>
        </TableContainer>
      )}
    </div>
  );
};

const CCDAViewer = ({ dataList }) => {
  return (
    <>
      <div>
        <Button>Upload Another File</Button>
      </div>
      <div className="ccda-viewer">
        {Object.keys(dataList).map((sectionKey, index) => (
          <CCDACard
            key={index}
            title={sectionKey}
            dataList={dataList[sectionKey][sectionKey] || []}
          />
        ))}
      </div>
    </>
  );
};

export default CCDAViewer;
